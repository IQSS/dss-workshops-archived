def f(x,y):
	return x + y


def g(x,y):
	"""g is a function that returns x times y """
	return x*y
