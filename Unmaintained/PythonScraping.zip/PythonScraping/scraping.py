import re
str = "Joseph Schmoe (15), Phone:(934) 292-2390, SSN:295-48-2019"
