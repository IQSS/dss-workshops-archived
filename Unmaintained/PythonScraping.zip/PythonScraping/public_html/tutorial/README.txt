This directory contains some simple code examples that are used with
the Wing IDE tutorial.  To read the tutorial, select it from the Help
menu in the IDE.

