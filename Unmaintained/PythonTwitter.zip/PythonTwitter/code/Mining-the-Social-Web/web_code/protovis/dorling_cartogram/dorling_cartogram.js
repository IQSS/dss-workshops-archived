var _data = {
    "NC": {
        "value": 1
    }, 
    "WA": {
        "value": 6
    }, 
    "BC": {
        "value": 1
    }, 
    "WI": {
        "value": 1
    }, 
    "FL": {
        "value": 3
    }, 
    "RU": {
        "value": 1
    }, 
    "NM": {
        "value": 1
    }, 
    "TX": {
        "value": 4
    }, 
    "LA": {
        "value": 1
    }, 
    "Dallas": {
        "value": 5
    }, 
    "TN": {
        "value": 16
    }, 
    "NY": {
        "value": 3
    }, 
    "Germany": {
        "value": 1
    }, 
    "RI": {
        "value": 1
    }, 
    "VA": {
        "value": 31
    }, 
    "The Netherlands": {
        "value": 1
    }, 
    "CO": {
        "value": 2
    }, 
    "CA": {
        "value": 37
    }, 
    "Sweden": {
        "value": 1
    }, 
    "AR": {
        "value": 2
    }, 
    "IL": {
        "value": 3
    }, 
    "GA": {
        "value": 3
    }, 
    "IN": {
        "value": 1
    }, 
    "IA": {
        "value": 1
    }, 
    "MA": {
        "value": 12
    }, 
    "AZ": {
        "value": 1
    }, 
    "MD": {
        "value": 4
    }, 
    "OK": {
        "value": 1
    }, 
    "Karnataka": {
        "value": 1
    }, 
    "OH": {
        "value": 1
    }, 
    "UT": {
        "value": 3
    }, 
    "MO": {
        "value": 1
    }, 
    "Minneapolis": {
        "value": 1
    }, 
    "United Kingdom": {
        "value": 1
    }, 
    "OR": {
        "value": 1
    }, 
    "SE": {
        "value": 1
    }
};

